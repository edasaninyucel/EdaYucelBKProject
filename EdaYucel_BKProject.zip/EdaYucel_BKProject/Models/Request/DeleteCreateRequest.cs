using System.Text.Json.Serialization;

namespace EdaYucel_BKProject.Models.Request;

public class DeleteCreateRequest
{
    
    [JsonPropertyName("CompanyId")]
    public string CompanyId { get; set; }
    
    [JsonPropertyName("EcosystemId")]
    public string EcosystemId { get; set; }
    
    
}